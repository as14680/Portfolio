
import { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ProjectCardProps {
  title: string;
  description: string;
  image: string;
  tags?: string[];
  link?: string;
  className?: string;
  reverse?: boolean;
}

const ProjectCard = ({
  title,
  description,
  image,
  tags = [],
  link,
  className,
  reverse = false,
}: ProjectCardProps) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      className={cn(
        'group grid md:grid-cols-2 gap-8 items-center py-12',
        reverse && 'md:grid-flow-dense',
        className
      )}
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
      viewport={{ once: true, margin: '-100px' }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className={cn('space-y-5', reverse && 'md:col-start-2')}>
        <div className="space-y-1">
          {tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-3">
              {tags.map((tag) => (
                <span 
                  key={tag}
                  className="px-2.5 py-0.5 text-xs font-medium bg-secondary rounded-full"
                >
                  {tag}
                </span>
              ))}
            </div>
          )}
          <h3 className="text-2xl font-bold">{title}</h3>
          <p className="text-base text-muted-foreground">{description}</p>
        </div>
        
        {link && (
          <motion.a
            href={link}
            className="inline-flex items-center text-sm font-medium"
            target="_blank"
            rel="noreferrer"
            whileHover={{ x: 5 }}
            transition={{ type: 'spring', stiffness: 400, damping: 10 }}
          >
            View project <ArrowUpRight size={16} className="ml-1" />
          </motion.a>
        )}
      </div>
      
      <div className={cn('overflow-hidden rounded-lg', !reverse && 'md:col-start-2')}>
        <motion.div
          className="w-full h-64 md:h-80 overflow-hidden rounded-lg"
          whileHover={{ scale: 1.03 }}
          transition={{ duration: 0.5 }}
        >
          <motion.img
            src={image}
            alt={title}
            className="w-full h-full object-cover"
            style={{ scale: isHovered ? 1.05 : 1 }}
            transition={{ duration: 0.7 }}
            loading="lazy"
          />
        </motion.div>
      </div>
    </motion.div>
  );
};

export default ProjectCard;
