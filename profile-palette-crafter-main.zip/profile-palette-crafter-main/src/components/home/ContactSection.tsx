
import { motion } from 'framer-motion';
import { Mail, Linkedin, Github, ExternalLink } from 'lucide-react';
import SectionHeading from '../ui/SectionHeading';

const ContactSection = () => {
  return (
    <section id="contact" className="py-24 px-6 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-full max-w-6xl h-[70%] bg-secondary/30 rounded-full blur-3xl opacity-50" />
      </div>
      
      <div className="max-w-7xl mx-auto relative z-10">
        <SectionHeading
          title="Let's Connect"
          subtitle="Interested in discussing product opportunities, technology innovations, or potential collaborations? I'd love to hear from you."
          badge="Contact"
          align="center"
        />
        
        <motion.div
          className="max-w-3xl mx-auto bg-background rounded-2xl shadow-sm border p-8 md:p-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true, margin: "-100px" }}
        >
          <div className="grid md:grid-cols-2 gap-10">
            <div>
              <h3 className="text-xl font-semibold mb-4">Get in Touch</h3>
              <p className="text-muted-foreground mb-6">
                I'm always open to discussing new projects, creative ideas or opportunities to be part of your vision.
              </p>
              
              <ul className="space-y-4">
                <li>
                  <a 
                    href="mailto:akshat.sharma@nyu.edu" 
                    className="flex items-center group"
                  >
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mr-3 group-hover:bg-primary/20 transition-colors">
                      <Mail size={18} className="text-primary" />
                    </div>
                    <div>
                      <span className="block text-sm text-muted-foreground">Email</span>
                      <span className="font-medium group-hover:text-primary transition-colors">akshat.sharma@nyu.edu</span>
                    </div>
                  </a>
                </li>
                <li>
                  <a 
                    href="https://www.linkedin.com/in/akshat-sharma-a4m" 
                    className="flex items-center group"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mr-3 group-hover:bg-primary/20 transition-colors">
                      <Linkedin size={18} className="text-primary" />
                    </div>
                    <div>
                      <span className="block text-sm text-muted-foreground">LinkedIn</span>
                      <span className="font-medium group-hover:text-primary transition-colors">linkedin.com/in/akshat-sharma-a4m</span>
                    </div>
                  </a>
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-4">Send a Message</h3>
              <form className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium mb-1">Name</label>
                  <input
                    type="text"
                    id="name"
                    className="w-full px-4 py-2 rounded-lg border bg-background focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium mb-1">Email</label>
                  <input
                    type="email"
                    id="email"
                    className="w-full px-4 py-2 rounded-lg border bg-background focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all"
                    placeholder="Your email"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium mb-1">Message</label>
                  <textarea
                    id="message"
                    rows={4}
                    className="w-full px-4 py-2 rounded-lg border bg-background focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all resize-none"
                    placeholder="Your message"
                  ></textarea>
                </div>
                <motion.button
                  type="submit"
                  className="w-full px-6 py-3 bg-foreground text-background font-medium rounded-lg transition-transform hover:scale-[1.02] active:scale-[0.98]"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Send Message
                </motion.button>
              </form>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default ContactSection;
