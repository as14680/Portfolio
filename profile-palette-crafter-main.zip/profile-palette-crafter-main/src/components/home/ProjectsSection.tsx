
import { motion } from 'framer-motion';
import SectionHeading from '../ui/SectionHeading';
import ProjectCard from '../ui/ProjectCard';

const projects = [
  {
    title: "Custom CMS Platform",
    description: "Led development of a centralized content management system to enhance scalability and operational efficiency across 113 client platforms, reducing content update time significantly.",
    image: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d",
    tags: ["Product Development", "Custom CMS", "WCGA 2.2 AAA Compliance", "Process Automation"],
    link: "#",
  },
  {
    title: "Retail Pricing Solution",
    description: "Designed an innovative pricing solution for a major retailer that achieved 40% growth in user adoption and reduced product launch cycles by 25%.",
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475",
    tags: ["Pricing Strategy", "Data Analytics", "User Adoption", "Product Launch"],
    link: "#",
    reverse: true,
  },
  {
    title: "Airtel VoLTE Mobile App",
    description: "Conceptualized an in-house mobile application enabling VoLTE services on non-compatible devices, reaching 50M+ customers across India.",
    image: "https://images.unsplash.com/photo-1649972904349-6e44c42644a7",
    tags: ["Telecom", "Mobile App", "VoLTE", "IoT Solutions"],
    link: "#",
  },
];

const ProjectsSection = () => {
  return (
    <section id="projects" className="py-20 px-6 relative overflow-hidden">
      <div className="max-w-7xl mx-auto relative z-10">
        <SectionHeading
          title="Featured Projects"
          subtitle="A selection of impactful projects I've led across telecom, payments, and B2B/B2C platforms."
          badge="Portfolio"
        />
        
        <motion.div
          className="space-y-16 md:space-y-24"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          {projects.map((project, index) => (
            <ProjectCard
              key={project.title}
              title={project.title}
              description={project.description}
              image={project.image}
              tags={project.tags}
              link={project.link}
              reverse={project.reverse}
            />
          ))}
        </motion.div>
      </div>
      
      <div className="absolute top-1/4 -right-64 w-96 h-96 bg-primary/5 rounded-full filter blur-3xl" />
      <div className="absolute bottom-1/4 -left-64 w-96 h-96 bg-primary/5 rounded-full filter blur-3xl" />
    </section>
  );
};

export default ProjectsSection;
