
import { motion } from 'framer-motion';
import SectionHeading from '../ui/SectionHeading';
import { Calendar, Building, Briefcase } from 'lucide-react';

const experiences = [
  {
    company: "ShyftLabs",
    role: "Product Manager",
    period: "September 2023 - Present",
    location: "New York City Metropolitan Area",
    description: [
      "Leading the development of a custom CMS to centralize website management, reduce content update time and enhance scalability across 113 client platforms.",
      "Designed a pricing solution for a retailer, achieving 40% growth in user adoption & a 25% reduction in product launch cycles.",
      "Led development of automated platforms for retail clients, cutting manual effort by 40% and improving resource allocation.",
      "Boosted QA team efficiency by 60% through process improvements, reducing time-to-market by 20%."
    ]
  },
  {
    company: "REX Property Holdings",
    role: "Co-Founder",
    period: "May 2022 - March 2023",
    location: "New York City Metropolitan Area",
    description: [
      "Streamlined developmental and product strategy, formulated tech stack, and designed business plan.",
      "Developed technical documentation to optimize platform development resourcing and costing.",
      "Structured engineering setup and product roadmap for company growth."
    ]
  },
  {
    company: "PayU",
    role: "Enterprise Solution Engineer",
    period: "March 2021 - July 2021",
    location: "Gurugram, Haryana, India",
    description: [
      "Managed development and launch of a new advertising platform, collaborating with engineering and design teams.",
      "Designed and launched a custom payment platform for a major E-commerce company, contributing to $53M Gross Merchandise Value.",
      "Partnered with sales and development teams to optimize payment structures, achieving 30% increase in operational efficiency."
    ]
  },
  {
    company: "Bharti Airtel",
    role: "Product Manager",
    period: "August 2017 - March 2021",
    location: "Gurgaon, India",
    description: [
      "Led automation process for a $4.8B project, streamlining site planning and deployment operations.",
      "Managed cross-functional teams and collaborated with key stakeholders to ensure project success.",
      "Conceptualized an in-house mobile app for 50M+ customers, enhancing accessibility and enabling VoLTE services."
    ]
  }
];

const ExperienceSection = () => {
  return (
    <section id="experience" className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <SectionHeading
          title="Professional Experience"
          subtitle="A track record of leading impactful products and driving business growth"
          badge="Experience"
        />
        
        <div className="relative">
          {/* Vertical timeline line */}
          <div className="absolute top-0 bottom-0 left-[15px] md:left-1/2 w-[2px] bg-border -ml-[1px] md:-ml-[1px]"></div>
          
          <div className="space-y-12 relative">
            {experiences.map((exp, index) => (
              <motion.div 
                key={index}
                className="relative grid md:grid-cols-2 gap-8 md:gap-0"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                {/* Timeline dot */}
                <div className="absolute top-0 left-0 md:left-1/2 w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center -ml-[15px] md:-ml-4 z-10">
                  <div className="w-3 h-3 bg-primary rounded-full"></div>
                </div>
                
                {/* Left content (right on mobile) */}
                <div className={`pl-12 md:pl-0 ${index % 2 === 0 ? 'md:text-right md:pr-8' : 'md:order-2 md:pl-8'}`}>
                  <div className="flex items-center mb-1 md:justify-end gap-2">
                    <Building size={16} className="text-primary" />
                    <h3 className="text-xl font-bold">{exp.company}</h3>
                  </div>
                  <div className="flex items-center mb-3 md:justify-end gap-2">
                    <Briefcase size={14} className="text-muted-foreground" />
                    <span className="font-medium">{exp.role}</span>
                  </div>
                  <div className="flex items-center mb-4 md:justify-end gap-2">
                    <Calendar size={14} className="text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">{exp.period}</span>
                    <span className="text-sm text-muted-foreground ml-2">{exp.location}</span>
                  </div>
                </div>
                
                {/* Right content (left on mobile) */}
                <div className={`pl-12 md:pl-0 ${index % 2 === 0 ? 'md:order-2 md:pl-8' : 'md:pr-8'}`}>
                  <ul className="space-y-2 list-disc list-outside ml-5">
                    {exp.description.map((item, i) => (
                      <li key={i} className="text-muted-foreground">
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ExperienceSection;
