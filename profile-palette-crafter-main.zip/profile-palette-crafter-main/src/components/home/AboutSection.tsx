
import { motion } from 'framer-motion';
import SectionHeading from '../ui/SectionHeading';
import { ArrowUpRight } from 'lucide-react';

const skills = [
  "Product Strategy",
  "Platform Automation",
  "Fintech & Payments",
  "B2B & B2C Apps",
  "Data-Driven Development",
  "Technical Leadership",
  "Process Optimization",
  "UX Research & Design",
  "Agile Methodologies",
  "Cross-Functional Collaboration",
  "Python, Java, C++",
  "SQL & Data Infrastructure"
];

const AboutSection = () => {
  return (
    <section id="about" className="py-24 px-6 bg-secondary/50">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, margin: "-100px" }}
          >
            <div className="aspect-square max-w-md rounded-2xl overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?q=80&w=2670&auto=format&fit=crop" 
                alt="Profile" 
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>
          
          <div>
            <SectionHeading
              title="About Me"
              subtitle="Bridging the gap between engineering and business to build exceptional products."
              badge="Hello!"
            />
            
            <motion.div
              className="space-y-4"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <p>
                As a Product Manager at ShyftLabs, I specialize in creating technical products for Fortune 500 companies, focusing on innovative pricing solutions for retail clients. With my Masters in Computer Science from NYU, I bring deep technical expertise to product leadership.
              </p>
              <p>
                My journey includes co-founding a tech startup, leading data-driven product initiatives at PayU and Bharti Airtel, and consulting on payment solutions. I've refined my expertise in AI, machine learning, databases, and scalable software development across multiple programming languages.
              </p>
              
              <div className="pt-4">
                <h3 className="text-lg font-semibold mb-3">Skills & Expertise</h3>
                <div className="flex flex-wrap gap-2">
                  {skills.map((skill) => (
                    <span 
                      key={skill} 
                      className="px-3 py-1 bg-background rounded-full text-sm"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
