
import { motion } from 'framer-motion';
import { ArrowDown } from 'lucide-react';

const HeroSection = () => {
  return (
    <section className="min-h-screen relative flex flex-col justify-center items-center pt-20 pb-16 px-6">
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-[30%] -right-[20%] w-[80%] h-[80%] rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute -bottom-[20%] -left-[20%] w-[70%] h-[70%] rounded-full bg-primary/5 blur-3xl" />
      </div>
      
      <div className="max-w-4xl mx-auto text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <span className="inline-block px-3 py-1 mb-6 text-xs font-medium bg-muted rounded-full">
            0 to 1 Product Manager
          </span>
        </motion.div>
        
        <motion.h1
          className="text-4xl md:text-6xl lg:text-7xl font-bold leading-tight mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          Akshat Sharma
        </motion.h1>
        
        <motion.p
          className="text-xl text-muted-foreground mb-10 max-w-2xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          I build products that blend technical expertise with business acumen. 
          With 6+ years of experience in telecom, payments, and B2B/B2C platforms,
          I've led projects impacting 50M+ users.
        </motion.p>
        
        <motion.div
          className="flex flex-col sm:flex-row gap-4 justify-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <a 
            href="#projects" 
            className="px-6 py-3 rounded-lg bg-foreground text-background font-medium transition-transform hover:scale-[1.03] active:scale-[0.97]"
          >
            View Projects
          </a>
          <a 
            href="#contact" 
            className="px-6 py-3 rounded-lg bg-secondary text-foreground font-medium transition-transform hover:scale-[1.03] active:scale-[0.97]"
          >
            Contact Me
          </a>
        </motion.div>
      </div>
      
      <motion.div
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 1.2, repeat: Infinity, repeatType: "reverse" }}
      >
        <a href="#about" className="flex flex-col items-center">
          <span className="text-sm font-medium mb-2 opacity-70">Learn More</span>
          <ArrowDown size={20} className="text-foreground/50" />
        </a>
      </motion.div>
    </section>
  );
};

export default HeroSection;
