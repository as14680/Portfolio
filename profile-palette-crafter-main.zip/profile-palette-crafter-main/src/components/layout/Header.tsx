
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const Header = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <motion.header
      className={cn(
        'fixed top-0 left-0 right-0 z-50 px-6 py-4 transition-all duration-300 ease-in-out',
        scrolled ? 'bg-background/80 backdrop-blur-xl border-b' : 'bg-transparent'
      )}
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.8 }}
        >
          <Link to="/" className="text-lg font-medium tracking-tight">
            Akshat Sharma
          </Link>
        </motion.div>

        <nav>
          <ul className="flex items-center space-x-8">
            {[
              { name: 'Home', path: '/' },
              { name: 'About', path: '/#about' },
              { name: 'Experience', path: '/#experience' },
              { name: 'Projects', path: '/#projects' },
              { name: 'Contact', path: '/#contact' }
            ].map((item, i) => (
              <motion.li
                key={item.name}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + i * 0.1, duration: 0.5 }}
              >
                <a
                  href={item.path}
                  className="text-sm font-medium opacity-70 hover:opacity-100 transition-opacity"
                >
                  {item.name}
                </a>
              </motion.li>
            ))}
          </ul>
        </nav>
      </div>
    </motion.header>
  );
};

export default Header;
