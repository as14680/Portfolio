
import { motion } from 'framer-motion';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <motion.footer
      className="w-full py-12 border-t bg-background/50 backdrop-blur-sm"
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
      viewport={{ once: true }}
    >
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          <div>
            <h3 className="text-lg font-semibold mb-4">Akshat Sharma</h3>
            <p className="text-sm text-muted-foreground max-w-xs">
              Building impactful products at the intersection of technology and business with an emphasis on user experience and operational efficiency.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Links</h3>
            <ul className="space-y-2">
              {[
                { name: 'Home', path: '/' },
                { name: 'About', path: '/#about' },
                { name: 'Experience', path: '/#experience' },
                { name: 'Projects', path: '/#projects' },
                { name: 'Contact', path: '/#contact' }
              ].map((item) => (
                <li key={item.name}>
                  <a 
                    href={item.path}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {item.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Connect</h3>
            <ul className="space-y-2">
              {[
                { name: 'Email', url: 'mailto:akshat.sharma@nyu.edu' },
                { name: 'LinkedIn', url: 'https://www.linkedin.com/in/akshat-sharma-a4m' }
              ].map((item) => (
                <li key={item.name}>
                  <a 
                    href={item.url}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                    target="_blank"
                    rel="noreferrer"
                  >
                    {item.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="mt-16 pt-8 border-t text-sm text-center text-muted-foreground">
          <p>© {currentYear} Akshat Sharma. All rights reserved.</p>
        </div>
      </div>
    </motion.footer>
  );
};

export default Footer;
